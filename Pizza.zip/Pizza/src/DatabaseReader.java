import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import javafx.scene.text.Text;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


// Document Builder
public class DatabaseReader {

    public DatabaseReader(String instruction) {
        try {
            //SET UP CONNECTION TO DATABASE----------------------------------------------------------------------------------------
            System.out.println("- - - LOG IN - - -");
            String dbUser = "pizza";
            String usrPass = "pizza";
            Class.forName("org.mariadb.jdbc.Driver");

            Connection con = null;

            String url = "jdbc:mariadb://10.140.214.96:3306/pizza";

            con = DriverManager.getConnection(url, dbUser, usrPass);

            System.out.println("connected!");

            Statement stmt = con.createStatement();

            // VIEW ALL ORDERS-----------------------------------------------------------------------------------------------------
            if (instruction.equalsIgnoreCase("view all orders")) {
                String showAll = "select * from orders;"; //TODO Jason - please enter the SQL query here!

                System.out.println("- - - SHOWING ALL ORDERS - - -");

                ResultSet rs = stmt.executeQuery(showAll);

                while (rs.next()) {//TODO this will print to the GUI in a future version
                    System.out.println("Order ID: " + rs.getInt("Order_ID"));
                    System.out.println("Customer Name: " + rs.getString("Customer_Name"));
                    //customer phone omitted
                    System.out.println("Order Time: " + rs.getInt("Order_Time"));
                    //complete time omitted
                    //price omitted
                    System.out.println("Order Status: " + rs.getString("Status"));
                    System.out.println("Order Details: " + rs.getString("orderdetail"));
                    System.out.println("===================");
                }
                rs.close();
                stmt.close();
                con.close();
                System.out.println("- - - connection closed - - -");
            }
            //VIEW NEW ORDERS ONLY -----------------------------------------------------------------------------------------------
            else if (instruction.equalsIgnoreCase("view new orders")){
                String showNew = "select * from orders;"; //TODO Jason - please enter the SQL query here!

                System.out.println("- - - SHOWING NEW ORDERS - - -");

                ResultSet rs = stmt.executeQuery(showNew);

                while (rs.next()) {//TODO this will print to the GUI in a future version
                    System.out.println("Order ID: " + rs.getInt("Order_ID"));
                    System.out.println("Customer Name: " + rs.getString("Customer_Name"));
                    //customer phone omitted
                    System.out.println("Order Time: " + rs.getInt("Order_Time"));
                    //complete time omitted
                    //price omitted
                    System.out.println("Order Status: " + rs.getString("Status"));
                    System.out.println("Order Details: " + rs.getString("orderdetail"));
                    System.out.println("===================");
                }
                rs.close();
                stmt.close();
                con.close();
                System.out.println("- - - connection closed - - -");
            }
            else if (instruction.equalsIgnoreCase("view current orders")){
                String showCurrent = "select * from orders;"; //TODO Jason - please enter the SQL query here!

                System.out.println("- - - SHOWING CURRENT ORDERS - - -");

                ResultSet rs = stmt.executeQuery(showCurrent);

                while (rs.next()) {//TODO this will print to the GUI in a future version
                    System.out.println("Order ID: " + rs.getInt("Order_ID"));
                    System.out.println("Customer Name: " + rs.getString("Customer_Name"));
                    //customer phone omitted
                    System.out.println("Order Time: " + rs.getInt("Order_Time"));
                    //complete time omitted
                    //price omitted
                    System.out.println("Order Status: " + rs.getString("Status"));
                    System.out.println("Order Details: " + rs.getString("orderdetail"));
                    System.out.println("===================");
                }
                rs.close();
                stmt.close();
                con.close();
                System.out.println("- - - connection closed - - -");
            }
            //VIEW COMPLETED ORDERS ONLY-------------------------------------------------------------------------------------------
            else if (instruction.equalsIgnoreCase("view completed orders")){
                String showCompleted = "select * from orders;"; //TODO Jason - please enter the SQL query here!

                System.out.println("- - - SHOWING COMPLETED ORDERS - - -");

                ResultSet rs = stmt.executeQuery(showCompleted);

                while (rs.next()) {//TODO this will print to the GUI in a future version
                    System.out.println("Order ID: " + rs.getInt("Order_ID"));
                    System.out.println("Customer Name: " + rs.getString("Customer_Name"));
                    //customer phone omitted
                    System.out.println("Order Time: " + rs.getInt("Order_Time"));
                    //complete time omitted
                    //price omitted
                    System.out.println("Order Status: " + rs.getString("Status"));
                    System.out.println("Order Details: " + rs.getString("orderdetail"));
                    System.out.println("===================");
                }
                rs.close();
                stmt.close();
                con.close();
                System.out.println("- - - connection closed - - -");
            }
            //VIEW INGREDIENT STOCK LEVELS----------------------------------------------------------------------------------------
            else if (instruction.equalsIgnoreCase("view stock")){
                String showAll = "select * from ingredients;"; //TODO Jason - please enter the SQL query here!

                System.out.println("- - - SHOWING ALL INGREDIENTS - - -");

                ResultSet rs = stmt.executeQuery(showAll);

                while (rs.next()) {//TODO this will print to the GUI in a future version
                    System.out.println("Ingredient ID: " + rs.getInt("id"));
                    System.out.println("Ingedient Name: " + rs.getString("name"));
                    System.out.println("Quantity Available: " + rs.getInt("Amount"));
                    System.out.println("Price Per Unit: " + rs.getString("Price"));
                    System.out.println("===================");
                }
                rs.close();
                stmt.close();
                con.close();
                System.out.println("- - - connection closed - - -");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("unable to log in. goodbye!");
        }
    }

    public static void main(String[] args) {
        new DatabaseReader("view completed orders");
    }
}