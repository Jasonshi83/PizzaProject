
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

public class KitchenGUI extends Application {

    public Stage pumpkin;
    public Scene reload;
    public KitchenGUI g = this;

    @Override
    public void start(Stage primaryStage) throws Exception {
        //INITIAL SET UP BELOW THIS LINE ------------------------------------------------------------------------------------------------------
        pumpkin = primaryStage;

        //layout parent
        BorderPane container = new BorderPane();

        //menu
        VBox leftMenu = new VBox();
        leftMenu.setId("leftMenu");
        leftMenu.setAlignment(Pos.TOP_LEFT);
        leftMenu.setPrefWidth(150);
        leftMenu.setPadding(new Insets(10, 10, 10, 10));
        leftMenu.setSpacing(10);

        //display zone
        VBox centerContent = new VBox();
        centerContent.setId("centerContent");
        centerContent.setPrefWidth(500); //set initial size?
        centerContent.setPrefHeight(400);
        centerContent.setPadding(new Insets(10, 10, 10, 10));
        ScrollPane contentHere = new ScrollPane();
        contentHere.fitToHeightProperty().set(true);
        contentHere.fitToWidthProperty().set(true);

        //ADD CONTENT TO DISPLAY TO CENTER CONTENT ONLY-------------------------------------------------------------------------

        contentHere.setContent(new Text("this is where orders and ingredients will be listed. We can choose from sub menus to make " +
                "even" +
                " more informed decisions!!"));

        centerContent.getChildren().add(contentHere);

        //MENU SET UP BELOW-------------------------------------------------------------------------

        //header
        HBox topMenu = new HBox();
        topMenu.setId("topMenu");
        topMenu.setPadding(new Insets(10, 10, 10, 10));
        topMenu.setSpacing(100);
        topMenu.setAlignment(Pos.CENTER_LEFT);

        //logo
        //Image puggle = new Image(getClass().getResourceAsStream("transparentpuggle.png"));
        ///** pug image from https://www.netclipart.com/down/ibiTTw_pizza-clipart-kawaii-puglie-pizza/ **/
        Image bulba = new Image(getClass().getResourceAsStream("transparentbulbasaurpizza.png"));
        ImageView logoView = new ImageView(bulba);
        logoView.setFitWidth(93.3);
        logoView.setFitHeight(70);

        topMenu.getChildren().add(logoView);

        //title
        Text topTitle = new Text("Pokémon Pizzeria");
        topTitle.setId("topTitle");
        topTitle.setFont(Font.loadFont("file:src/Fonts/wavepool.ttf", 56));
        topMenu.getChildren().add(topTitle);

        //date + time display
        LocalDate date = LocalDate.now();
        DateTimeFormatter formattedDate = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String dateDisplay = date.format(formattedDate);
        Text showDate = new Text(dateDisplay);
        topMenu.getChildren().add(showDate);

        LocalTime time = LocalTime.now();
        DateTimeFormatter formattedTime = DateTimeFormatter.ofPattern("HH:mm:ss");
        String timeDisplay = time.format(formattedTime);
        Text showTime = new Text(timeDisplay);
        topMenu.getChildren().add(showTime);
        bindToTime(showTime);// this calls the method for the clock to update every second

        //ACTION LISTENERS BELOW-------------------------------------------------------------------------

        Text addHeading = new Text("Add");
        addHeading.setFont(Font.loadFont("file:src/Fonts/ZukaDoodle.ttf", 20));
        leftMenu.getChildren().add(addHeading);

        Button addNewIngredient = new Button("New Ingredient");
        addNewIngredient.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                centerContent.getChildren().clear();
                centerContent.getChildren().add(new Text("I am adding a new ingredient option!"));
                g.refresh();
            }
        });
        leftMenu.getChildren().add(addNewIngredient);

        Text viewHeading = new Text("View");
        viewHeading.setFont(Font.loadFont("file:src/Fonts/jabjai_light.ttf", 20));
        leftMenu.getChildren().add(viewHeading);

        Button currentOrders = new Button("Current Orders");
        currentOrders.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                centerContent.getChildren().clear();
                centerContent.getChildren().add(new Text("I am showing all current orders!"));
                g.refresh();
            }
        });
        leftMenu.getChildren().add(currentOrders);

        Button completedOrders = new Button("Completed Orders");
        completedOrders.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                centerContent.getChildren().clear();
                centerContent.getChildren().add(new Text("I am showing all completed orders!"));
                g.refresh();
            }
        });
        leftMenu.getChildren().add(completedOrders);

        Text updateHeading = new Text("Update");
        updateHeading.setFont(Font.loadFont("file:src/Fonts/jabjai_heavy.ttf", 20));
        leftMenu.getChildren().add(updateHeading);

        Button updateStock = new Button("Update Stock");
        updateStock.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                centerContent.getChildren().clear();
                centerContent.getChildren().add(new Text("I am updating stock levels!"));
                g.refresh();
            }
        });
        leftMenu.getChildren().add(updateStock);

        //FINAL SET UP BELOW-------------------------------------------------------------------------

        container.setLeft(leftMenu);
        container.setCenter(centerContent);
        container.setTop(topMenu);

        reload = new Scene(container);
        reload.getStylesheets().add("PizzaPugStyle.css");

        primaryStage.setTitle("♥.∙: *∞* :∙.♥.∙: *∞* :∙.♥ Pizza Pug Kitchen App ♥.∙: *∞* :∙.♥.∙: *∞* :∙.♥");
        primaryStage.setScene(reload);
        primaryStage.show();
    }

    //REFRESH SCENE METHOD--------------------------------------------------------------------------------------------------------
    public void refresh() {
        System.out.println("refreshing scene...");
        pumpkin.setScene(reload);
        pumpkin.show();
    }

    //CLOCK UDPATE METHOD---------------------------------------------------------------------------------------------------------
    private void bindToTime(Text display) {
        Timeline timeline = new Timeline(
                //what to reload
                new KeyFrame(Duration.seconds(0),
                        new EventHandler<ActionEvent>() {
                            @Override public void handle(ActionEvent actionEvent) {
                                Calendar time = Calendar.getInstance();
                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
                                display.setText(simpleDateFormat.format(time.getTime()));
                                g.refresh();
                            }
                        }
                ),
                //wait a second!
                new KeyFrame(Duration.seconds(1))
        );
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
